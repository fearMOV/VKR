create function eval(expr character varying) returns character varying
  language plpgsql
as
$$
declare    row record;    res varchar; begin    if lower(expr) in ('true','false') then res := expr;    else        for row in execute 'select (' || expr || ')::text as res1' loop            res := row.res1;        end loop;    end if;    return res; end
$$;

alter function eval(varchar) owner to naucrm;

