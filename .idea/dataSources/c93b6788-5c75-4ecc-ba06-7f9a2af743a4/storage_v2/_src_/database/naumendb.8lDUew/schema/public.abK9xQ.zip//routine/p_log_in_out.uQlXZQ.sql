create function p_log_in_out(start_time date, stop_time date, start_window character DEFAULT '00:00'::bpchar, stop_window character DEFAULT '23:59'::bpchar) returns SETOF t_offline
  language plpgsql
as
$$
declare
i record;
line record;
LEN NUMERIC:=0;
begin
  line := cast(ROW(null,null,null,null) as t_offline);
  for i in (
              select
                "intr"."p_begin" as DT,
                coalesce(log_in.LOGIN, log_out.LOGIN) as LOGIN,
                log_in.LOG_IN as LOG_IN,
                log_out.LOG_OUT as LOG_OUT
              from
              intervalize(START_TIME, STOP_TIME, 'DD', 1) intr
              left join
              (
                select
                  "voc"."CHANGE_DATE" as CHANGE_DATE,
                  "voc"."LOGIN" as LOGIN,
                  min("voc"."CHANGE_TIME") as LOG_IN
                from "public"."V_ONLINE_CHANGED" voc
                where
                  "voc"."DIRECTION" = 'in'
                  and "voc"."CHANGE_TIME" between START_TIME and STOP_TIME
                  and "voc"."CHANGE_TIME" between "WINDOWTOTIMESTAMP"("voc"."CHANGE_TIME", START_WINDOW) and "WINDOWTOTIMESTAMP"("voc"."CHANGE_TIME", STOP_WINDOW)
                group by "voc"."CHANGE_DATE", "voc"."LOGIN"
              ) log_in on (log_in.CHANGE_DATE = "intr"."p_begin")
              left join
              (
                select
                  "voc"."CHANGE_DATE" as CHANGE_DATE,
                  "voc"."LOGIN" as LOGIN,
                  max("voc"."CHANGE_TIME") as LOG_OUT
                from "public"."V_ONLINE_CHANGED" voc
                where
                  "voc"."DIRECTION" = 'out'
                  and "voc"."CHANGE_TIME" between START_TIME and STOP_TIME
                  and "voc"."CHANGE_TIME" between "WINDOWTOTIMESTAMP"("voc"."CHANGE_TIME", START_WINDOW) and "WINDOWTOTIMESTAMP"("voc"."CHANGE_TIME", STOP_WINDOW)
                group by "voc"."CHANGE_DATE", "voc"."LOGIN"
              ) log_out on (log_out.CHANGE_DATE = "intr"."p_begin" and log_out.LOGIN = log_in.LOGIN and log_out.LOG_OUT >= log_in.LOG_IN)
            )
    loop
      line := cast(ROW(i.DT, i.LOGIN, i.LOG_IN, i.LOG_OUT) as t_offline);
      return next line;
    end loop;
  return;
end;
$$;

alter function p_log_in_out(date, date, char, char) owner to naucrm;

