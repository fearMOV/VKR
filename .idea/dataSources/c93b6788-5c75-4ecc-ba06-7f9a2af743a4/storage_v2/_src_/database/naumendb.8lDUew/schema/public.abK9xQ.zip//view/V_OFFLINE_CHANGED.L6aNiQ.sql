create view "V_OFFLINE_CHANGED" as
  SELECT to_date(to_char(vst."ENTERED", 'yyyy-mm-dd'::text), 'yyyy-mm-dd'::text) AS "CHANGE_DATE",
         vst."ENTERED"                                                           AS "CHANGE_TIME",
         vst."LOGIN",
         'in'::text                                                              AS "DIRECTION"
  FROM "V_STATUS_CHANGES" vst
  WHERE ((vst."STATUS")::text = 'offline'::text)
  UNION ALL
  SELECT to_date(
             to_char((status_changes.entered + ((status_changes.duration)::double precision * '00:00:01'::interval)),
                     'yyyy-mm-dd'::text), 'yyyy-mm-dd'::text)                                            AS "CHANGE_DATE",
         (status_changes.entered +
          ((status_changes.duration)::double precision * '00:00:01'::interval))                          AS "CHANGE_TIME",
         status_changes.login                                                                            AS "LOGIN",
         'out'::text                                                                                     AS "DIRECTION"
  FROM status_changes
  WHERE ((status_changes.status)::text = 'offline'::text);

alter table "V_OFFLINE_CHANGED"
  owner to naucrm;

