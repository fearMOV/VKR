create view "V_STATUS_CHANGES2" as
  SELECT status_changes.entered  AS "ENTERED",
         status_changes.login    AS "LOGIN",
         status_changes.status   AS "STATUS",
         status_changes.reason   AS "REASON",
         status_changes.duration AS "DURATION",
         status_changes.leaved   AS "LEAVED"
  FROM status_changes
  UNION ALL
  SELECT cur_statuses.entered                                                      AS "ENTERED",
         cur_statuses.login                                                        AS "LOGIN",
         cur_statuses.status                                                       AS "STATUS",
         cur_statuses.reason                                                       AS "REASON",
         intervaltosec((now() - (cur_statuses.entered)::timestamp with time zone)) AS "DURATION",
         (now())::timestamp without time zone                                      AS "LEAVED"
  FROM cur_statuses;

alter table "V_STATUS_CHANGES2"
  owner to naucrm;

