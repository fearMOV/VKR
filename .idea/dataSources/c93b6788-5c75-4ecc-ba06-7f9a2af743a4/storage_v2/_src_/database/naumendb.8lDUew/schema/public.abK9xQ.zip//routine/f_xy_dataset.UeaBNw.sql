create function f_xy_dataset(f character varying, xmin real, xmax real, n integer) returns TABLE(x real, y real)
  language plpgsql
as
$$
declare     m int;     deltax real; begin     m = n;     if m > 2 then        m := m - 1;     end if;     deltax := (xmax - xmin)/m;     for i in 0..m loop         x := xmin + i*deltax;         y := eval(replace(f, '$x', '(' || x || ')'));         return next;     end loop; end
$$;

alter function f_xy_dataset(varchar, real, real, integer) owner to naucrm;

