create function p_queue_len(start_time timestamp without time zone, stop_time timestamp without time zone) returns SETOF t_queue_len
  language plpgsql
as
$$
declare
i record;
line record;
begin
  line := cast(ROW(' ',null,0) AS t_queue_len);
  for i in (
    select
      PROJECT_ID as PROJECT_ID,
      CHANGED as CHANGED,
      COUNTER as COUNTER
    from
    (
      select
        que.PROJECT_ID as PROJECT_ID,
        que.unblocked_time as changed,
        1 as counter
      from
          queued_calls que
          where
          que.UNBLOCKED_TIME is not null
      union all
      select
        que.PROJECT_ID as PROJECT_ID,
        que.dequeued_time as changed,
        -1 as counter
      from
          queued_calls que
          where
                que.UNBLOCKED_TIME is not null
    ) AS foo
    where changed between START_TIME and STOP_TIME
    order by PROJECT_ID, CHANGED, COUNTER desc)
    loop
        if (line.PROJECT_ID <> i.PROJECT_ID)
        then
            begin
                line := cast(ROW(' ',null,0) AS t_queue_len);
            end;
        end if;

        line.PROJECT_ID := i.PROJECT_ID;
        line.CHANGED := i.CHANGED;
        line.AMOUNT := line.AMOUNT + i.COUNTER;
        return next line;
    end loop;
  return;
end;
$$;

alter function p_queue_len(timestamp, timestamp) owner to naucrm;

