create view groups as
SELECT DISTINCT abonents.id,
                abonents.login,
                abonents.name
FROM (abonents_hier
       LEFT JOIN abonents ON ((abonents.id = abonents_hier.parent)));

alter table groups
  owner to naucrm;

