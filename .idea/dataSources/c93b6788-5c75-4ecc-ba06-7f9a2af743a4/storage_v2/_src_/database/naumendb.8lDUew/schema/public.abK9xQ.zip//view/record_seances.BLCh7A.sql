create view record_seances as
  SELECT rec.session_id,
         cl1.src_abonent              AS operator_login,
         cl2.dst_id                   AS remote_phone,
         cl1.created                  AS call_time,
         'out'::character varying(10) AS direction,
         rec.record_length            AS record_len,
         rec.filename                 AS file_name
  FROM records40 rec,
       audio_links al,
       call_legs cl1,
       call_legs cl2
  WHERE (((cl1.id)::text = (al.src_leg)::text) AND ((cl2.id)::text = (al.dst_leg)::text) AND
         ((rec.session_id)::text = (cl1.session_id)::text) AND ((rec.session_id)::text = (cl2.session_id)::text) AND
         ((al.src_leg)::text < (al.dst_leg)::text) AND (cl1.incoming = 1) AND (cl1.src_abonent IS NOT NULL))
  UNION
  SELECT rec.session_id,
         cl2.dst_abonent             AS operator_login,
         cl1.src_id                  AS remote_phone,
         cl1.created                 AS call_time,
         'in'::character varying(10) AS direction,
         rec.record_length           AS record_len,
         rec.filename                AS file_name
  FROM records40 rec,
       audio_links al,
       call_legs cl1,
       call_legs cl2
  WHERE (((cl1.id)::text = (al.src_leg)::text) AND ((cl2.id)::text = (al.dst_leg)::text) AND
         ((rec.session_id)::text = (cl1.session_id)::text) AND ((rec.session_id)::text = (cl2.session_id)::text) AND
         ((al.src_leg)::text < (al.dst_leg)::text) AND (cl2.incoming = 0) AND (cl2.dst_abonent IS NOT NULL));

alter table record_seances
  owner to naucrm;

