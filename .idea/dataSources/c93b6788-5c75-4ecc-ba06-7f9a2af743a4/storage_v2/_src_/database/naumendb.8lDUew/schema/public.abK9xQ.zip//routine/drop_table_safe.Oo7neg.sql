create function drop_table_safe(character varying) returns void
  language plpgsql
as
$$
BEGIN     IF EXISTS(SELECT * FROM information_schema.tables WHERE lower(table_name) = lower($1) and table_schema = current_schema())     THEN         EXECUTE 'DROP TABLE ' || $1;     END IF; END
$$;

alter function drop_table_safe(varchar) owner to naucrm;

