create function get_holds_count(sess character varying, oper character varying) returns numeric
  language plpgsql
as
$$
DECLARE
    CNT Numeric;
    Begin
        select coalesce(count(*),0) into CNT
        from call_status
        where session_id = sess
            and initiator_id = oper;
    Return(CNT);
    End;
$$;

alter function get_holds_count(varchar, varchar) owner to naucrm;

