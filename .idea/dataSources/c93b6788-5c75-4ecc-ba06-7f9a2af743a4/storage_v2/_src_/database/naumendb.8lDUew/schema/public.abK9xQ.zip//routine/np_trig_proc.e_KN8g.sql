create function np_trig_proc() returns trigger
  language plpgsql
as
$$
BEGIN
                          IF (TG_OP = 'INSERT') THEN
                            INSERT INTO np_tmp_trigdata VALUES(NEXTVAL('np_tmp_trigdata_id_gen'), TG_RELNAME, NEW.id);
                          ELSIF (TG_OP = 'DELETE') THEN
                            INSERT INTO np_tmp_trigdata VALUES(NEXTVAL('np_tmp_trigdata_id_gen'), TG_RELNAME, OLD.id);
                          ELSIF (TG_OP = 'UPDATE') THEN
                            INSERT INTO np_tmp_trigdata VALUES(NEXTVAL('np_tmp_trigdata_id_gen'), TG_RELNAME, NEW.id);
                            if NEW.id <> OLD.id THEN
                              INSERT INTO np_tmp_trigdata VALUES(TG_RELNAME, OLD.id);
                            END IF;
                          END IF;
                          NOTIFY np_trig_notify;
                          RETURN NEW;
                        END
$$;

alter function np_trig_proc() owner to naucrm;

