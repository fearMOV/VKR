create function p_statuses_duration_per_date(start_time timestamp without time zone, stop_time timestamp without time zone, start_window character varying DEFAULT '00:00'::character varying, stop_window character varying DEFAULT '23:59'::character varying) returns SETOF t_statuses
  language plpgsql
as
$$
DECLARE
i record;
LINE record;
CT DATE:=null;
begin
  LINE:=cast(ROW(null,null,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0) AS T_STATUSES);
  CT := start_time;
  while CT < stop_time
    loop
      for i in
      (
         select
            login,
            accident,
            available,
            away,
            away_dinner,
            away_technicalbreak,
            away_custom_reason1,
            away_custom_reason2,
            away_custom_reason3,
            away_custom_reason4,
            away_custom_reason5,
            away_custom_reason6,
            away_custom_reason7,
            away_custom_reason8,
            away_custom_reason9,
            away_custom_reason10,
            custom1,
            custom2,
            custom3,
            dnd,
            normal,
            notavailable,
            "OFF",
            redirect,
            ringing,
            speaking,
            standoff,
            wrapup
            from p_statuses_duration("WINDOWTOTIMESTAMP"(CT,start_window),"WINDOWTOTIMESTAMP"(CT,stop_window))
      )
      loop
        LINE:=cast(ROW(CT, i.login, i.accident, i.available, i.away, i.away_dinner, i.away_technicalbreak, i.away_custom_reason1, i.away_custom_reason2, i.away_custom_reason3, i.away_custom_reason4, i.away_custom_reason5, i.away_custom_reason6, i.away_custom_reason7, i.away_custom_reason8, i.away_custom_reason9, i.away_custom_reason10, i.custom1, i.custom2, i.custom3, i.dnd, i.normal, i.notavailable, i."OFF", i.redirect, i.ringing, i.speaking, i.standoff, i.wrapup) AS T_STATUSES);
        return next LINE;
      end loop;
      CT := CT + 1;
    end loop;
    return next LINE;
    return;
end;
$$;

alter function p_statuses_duration_per_date(timestamp, timestamp, varchar, varchar) owner to naucrm;

