create function intervaltosec(interval) returns numeric
  language plpgsql
as
$$
DECLARE intr ALIAS FOR $1; BEGIN return extract( SECOND from intr )+extract( MINUTE from intr )*60+extract( HOUR from intr )*60*60+extract( DAY from intr )*60*60*24;END;
$$;

alter function intervaltosec(interval) owner to naucrm;

