create function ai_sessions_colr_trigger() returns trigger
  language plpgsql
as
$$
DECLARE

BEGIN

    INSERT INTO sessions_for_update (session_id, created) VALUES (NEW.session_id, NEW.created);
    RETURN NULL;

END;
$$;

alter function ai_sessions_colr_trigger() owner to naucrm;

