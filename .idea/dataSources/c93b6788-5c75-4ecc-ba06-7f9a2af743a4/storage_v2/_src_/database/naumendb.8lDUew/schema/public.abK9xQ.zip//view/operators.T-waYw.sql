create view operators as
SELECT abonents.id,
       abonents.login,
       abonents.name
FROM (abonents
       LEFT JOIN abonents_hier ON ((abonents.id = abonents_hier.parent)))
WHERE (abonents_hier.parent IS NULL);

alter table operators
  owner to naucrm;

