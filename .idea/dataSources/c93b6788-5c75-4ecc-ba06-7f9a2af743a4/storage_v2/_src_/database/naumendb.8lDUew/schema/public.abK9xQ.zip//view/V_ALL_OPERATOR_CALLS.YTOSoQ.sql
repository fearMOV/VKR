create view "V_ALL_OPERATOR_CALLS" as
  SELECT cl.session_id                          AS "SESSION_ID",
         cl.leg_id                              AS "LEG_ID",
         p.param_value                          AS "PARENTUUID",
         cl.src_abonent                         AS "LOGIN",
         cl.dst_id                              AS "ABONENT",
         cl.created                             AS "CREATED",
         cl.connected                           AS "CONNECTED",
         cl.ended                               AS "ENDED",
         cl.voip_reason                         AS "VOIP_REASON",
         cl.internal_reason                     AS "INTERNAL_REASON",
         CASE
           WHEN (cl.connected IS NOT NULL) THEN intervaltosec((cl.connected - cl.created))
           ELSE (0)::numeric
           END                                  AS "PICKUP_TIME",
         CASE
           WHEN (cl.connected IS NOT NULL) THEN intervaltosec((cl.ended - cl.connected))
           ELSE (0)::numeric
           END                                  AS "SPEAKING_TIME",
         intervaltosec((cl.ended - cl.created)) AS "TOTAL_TIME",
         'out'::text                            AS "DIRECTION"
  FROM (call_legs cl
         LEFT JOIN call_params p ON ((((p.session_id)::text = (cl.session_id)::text) AND ((p.param_name)::text = ANY
                                                                                          (ARRAY [('case_uuid'::character varying)::text, ('npcp-dialer-client-ext-id'::character varying)::text])))))
  WHERE (((cl.src_abonent_type)::text = 'SP'::text) AND (cl.incoming = 1) AND (cl.intrusion = 0))
  UNION ALL
  SELECT cl.session_id                          AS "SESSION_ID",
         cl.leg_id                              AS "LEG_ID",
         p.project_id                           AS "PARENTUUID",
         cl.dst_abonent                         AS "LOGIN",
         cl.src_id                              AS "ABONENT",
         cl.created                             AS "CREATED",
         cl.connected                           AS "CONNECTED",
         cl.ended                               AS "ENDED",
         cl.voip_reason                         AS "VOIP_REASON",
         cl.internal_reason                     AS "INTERNAL_REASON",
         CASE
           WHEN (cl.connected IS NOT NULL) THEN intervaltosec((cl.connected - cl.created))
           ELSE (0)::numeric
           END                                  AS "PICKUP_TIME",
         CASE
           WHEN (cl.connected IS NOT NULL) THEN intervaltosec((cl.ended - cl.connected))
           ELSE (0)::numeric
           END                                  AS "SPEAKING_TIME",
         intervaltosec((cl.ended - cl.created)) AS "TOTAL_TIME",
         'in'::text                             AS "DIRECTION"
  FROM (call_legs cl
         LEFT JOIN queued_calls p
                   ON ((((p.session_id)::text = (cl.session_id)::text) AND (cl.created >= p.unblocked_time) AND
                        (cl.created <= p.dequeued_time))))
  WHERE (((cl.dst_abonent_type)::text = 'SP'::text) AND (cl.incoming = 0) AND (cl.intrusion = 0));

alter table "V_ALL_OPERATOR_CALLS"
  owner to naucrm;

