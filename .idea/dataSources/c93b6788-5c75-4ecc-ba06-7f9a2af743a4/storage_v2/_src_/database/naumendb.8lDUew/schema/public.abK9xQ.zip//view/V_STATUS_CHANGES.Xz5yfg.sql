create view "V_STATUS_CHANGES" as
  SELECT status_changes.entered  AS "ENTERED",
         status_changes.login    AS "LOGIN",
         status_changes.status   AS "STATUS",
         status_changes.reason   AS "REASON",
         status_changes.duration AS "DURATION"
  FROM status_changes
  UNION ALL
  SELECT cur_statuses.entered                                                      AS "ENTERED",
         cur_statuses.login                                                        AS "LOGIN",
         cur_statuses.status                                                       AS "STATUS",
         cur_statuses.reason                                                       AS "REASON",
         intervaltosec((now() - (cur_statuses.entered)::timestamp with time zone)) AS "DURATION"
  FROM cur_statuses;

alter table "V_STATUS_CHANGES"
  owner to naucrm;

