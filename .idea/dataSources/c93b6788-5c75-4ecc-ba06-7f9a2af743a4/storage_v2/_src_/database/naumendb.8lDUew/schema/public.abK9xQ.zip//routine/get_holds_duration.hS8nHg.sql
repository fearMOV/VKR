create function get_holds_duration(sess character varying, oper character varying) returns numeric
  language plpgsql
as
$$
DECLARE
    CNT Numeric;
    Begin
        select coalesce(sum(INTERVALTOSEC(ended-entered)),0) into CNT
        from call_status
        where session_id = sess
        and initiator_id = oper;
    Return(CNT);
    End;
$$;

alter function get_holds_duration(varchar, varchar) owner to naucrm;

