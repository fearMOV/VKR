create function getshortphonenumber(character varying, integer) returns character varying
  language plpgsql
as
$$
DECLARE     len integer := length($1); BEGIN     IF (len > $2) THEN RETURN substr($1, len - $2 + 1, $2); END IF;     RETURN $1; END
$$;

alter function getshortphonenumber(varchar, integer) owner to naucrm;

