create view conversations as
SELECT audio_links.id,
       audio_links.src_leg,
       audio_links.dst_leg,
       call_legs.session_id,
       call_legs.protocol,
       call_legs.src_ip,
       call_legs.src_port,
       call_legs.dst_ip,
       call_legs.dst_port,
       call_legs.src_id,
       call_legs.dst_id,
       call_legs.src_abonent,
       call_legs.dst_abonent,
       call_legs.src_abonent_type,
       call_legs.dst_abonent_type,
       call_legs.incoming,
       call_legs.intrusion,
       call_legs.connected,
       audio_links.ended
FROM (audio_links
       JOIN call_legs ON ((((call_legs.id)::text = (audio_links.src_leg)::text) OR
                           ((call_legs.id)::text = (audio_links.dst_leg)::text))))
WHERE ((audio_links.src_leg)::text > (audio_links.dst_leg)::text);

alter table conversations
  owner to naucrm;

