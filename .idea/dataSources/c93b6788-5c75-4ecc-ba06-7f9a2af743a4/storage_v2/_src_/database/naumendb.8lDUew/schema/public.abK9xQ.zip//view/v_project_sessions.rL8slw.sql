create view v_project_sessions as
  SELECT project_sessions.project_id,
         project_sessions.session_id,
         project_sessions.sessions_count,
         project_sessions.event,
         project_sessions."timestamp",
         project_sessions.duration,
         project_sessions.leaved
  FROM project_sessions
  UNION ALL
  SELECT last_project_sessions.project_id,
         last_project_sessions.session_id,
         last_project_sessions.sessions_count,
         last_project_sessions.event,
         last_project_sessions."timestamp",
         intervaltosec((now() - (last_project_sessions."timestamp")::timestamp with time zone)) AS duration,
         (now())::timestamp without time zone                                                   AS leaved
  FROM last_project_sessions;

alter table v_project_sessions
  owner to naucrm;

