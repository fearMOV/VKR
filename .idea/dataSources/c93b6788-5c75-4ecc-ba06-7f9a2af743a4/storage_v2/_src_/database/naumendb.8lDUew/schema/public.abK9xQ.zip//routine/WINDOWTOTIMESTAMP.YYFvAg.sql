create function "WINDOWTOTIMESTAMP"(t timestamp without time zone, ch character varying) returns timestamp without time zone
  language plpgsql
as
$$
Begin
      if ch = '23:59' then
        return to_date(to_char(t, 'yyyy-mm-dd'), 'yyyy-mm-dd')+1;
      else return to_date(to_char(t, 'yyyy-mm-dd')||' '||ch, 'yyyy-mm-dd hh24-mi');
      end if;
End;
$$;

alter function "WINDOWTOTIMESTAMP"(timestamp, varchar) owner to naucrm;

