create function intervalize(p_begin timestamp without time zone, p_end timestamp without time zone, intrvl character DEFAULT 'DD'::bpchar, intrvl_len integer DEFAULT 1, prec integer DEFAULT 0, sf character DEFAULT 'DD.MM.YYYY HH24:MI'::bpchar, df character varying DEFAULT ' - '::character varying, ff character DEFAULT 'DD.MM.YYYY HH24:MI'::bpchar) returns SETOF interval_obj
  language plpgsql
as
$$
declare
i interval_obj;
d interval;
cut_date character varying(10);
begin
  d := case
    when intrvl = 'MI' then interval'1 min'
    when intrvl = 'HH24' then interval'1 hour'
    when intrvl = 'DD' then interval'1 day'
    when intrvl = 'DY' then interval'1 week'
    when intrvl = 'MM' then interval'1 month'
    when intrvl = 'Q' then interval'3 months'
    when intrvl = 'YY' then interval'1 year'
  end;
  cut_date := case
    when intrvl = 'MI' then 'minute'
    when intrvl = 'HH24' then 'hour'
    when intrvl = 'DD' then 'day'
    when intrvl = 'DY' then 'week'
    when intrvl = 'MM' then 'month'
    when intrvl = 'Q' then 'quarter'
    when intrvl = 'YY' then 'year'
  end;
  for i in
(select (case when inp_begin < p_begin AND prec > 0 then p_begin else inp_begin end),
        (case when inp_end > p_end AND prec > 0 then p_end else inp_end end),
        to_char((case when inp_begin < p_begin AND prec > 0 then p_begin else inp_begin end), sf) || df || to_char((case when inp_end > p_end AND prec > 0 then p_end else inp_end end), ff) from
        (select
date_trunc(cut_date, p_begin) + s.a*d as inp_begin,
cast(date_trunc(cut_date, p_begin) + s.a*d + (case when intrvl_len = 0 then 1 else intrvl_len end)*d as timestamp) as inp_end from generate_series(0, cast(ceil(intervaltosec(p_end-p_begin)/extract(epoch from d)) as bigint), (case when intrvl_len = 0 then 1 else intrvl_len end)) as s(a)) as foo)
        loop
                if i.p_begin >= p_end then return; end if;
                return next i;
        end loop;
        return;
end;
$$;

alter function intervalize(timestamp, timestamp, char, integer, integer, char, varchar, char) owner to naucrm;

